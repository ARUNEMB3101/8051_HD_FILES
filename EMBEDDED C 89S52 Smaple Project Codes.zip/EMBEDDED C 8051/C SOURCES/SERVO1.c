#include <AT89S52.h>
#define TRIG P0_0
#include <SERVO.h>

void main()
{
 int n;
 servo_init();
 while(1)
 {
   run_servo(9);
   delay(3);
   run_servo(5);
   delay(3);
   run_servo(1);
   delay(3);
 }
}