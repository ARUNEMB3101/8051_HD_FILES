#include <AT89S52.h>

#define RS P0_2
#define RW P0_1
#define EN P0_0
#define DATABUS P2
#include <LCD.h>

#define ADC P3
#define A2 P0_3
#define A1 P0_4
#define A0 P0_5
#define AE P1_0
#define SOC P1_1
#define EOC P1_2
#define OE P1_3
#define REL P0_6

char h,t,o;

void main()
{
 char v=0;
 ADC=0xFF;
 A2=0;A1=1;A0=1;AE=0;SOC=0;EOC=1;OE=0;
 REL=1;
 lcd_init();
 lcd_print("ADC VALUE= ");
 while(1)
 {
  AE=1;
  SOC=1;
  AE=0;
  SOC=0;
  while(EOC==1)
  {}
  while(EOC==0)
  {}
  OE=1;
  v=ADC;
  if(v>33)
  {
   REL=0;
  }
  else
  {
   REL=1;
  }
  h=(v/100)|0x30;
  t=((v/10)%10)|0x30;
  o=(v%10)|0x30;
  lcd_pos(1,12);
  lcd_data(h);
  lcd_data(t);
  lcd_data(o);
  delay(1);
 }
}