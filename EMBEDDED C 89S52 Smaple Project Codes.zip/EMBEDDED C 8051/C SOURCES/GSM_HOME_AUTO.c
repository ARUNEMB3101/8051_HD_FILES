#include <AT89S52.h>

#define GSM_FOSC 11059200
#define GSM_CLK GSM_FOSC/384

#define RS P1_0
#define RW P1_1
#define EN P1_2
#define DATABUS P0
#include <LCD.h>

#define LAMP P2_0

void start_serial(long int);
void send_mess(char*);
void trans_wait(void);
void get_msg(void);
void rec_wait(void);
__bit check_msg(char*);

__bit sent,rec,chk;
char msg[70];
char mob[11];
char *m;
void main()
{
 char i;
 sent=0;
 rec=0;
 m=&msg[0];
 LAMP=1;
 lcd_init();
 start_serial(9600);
 lcd_print("GSM HOME AUTOMAT");
 REN=0;
 delay(5);
 send_mess("ATE0\r\n");
 delay(1);
 send_mess("AT+CMGF=1\r\n");
 delay(1);
 send_mess("AT+CMGDA=\"DEL ALL\"\r\n");
 delay(2);
 while(1)
 {
  REN=1;
  rec_wait();
  rec_wait();
  send_mess("AT+CMGR=1\r\n");
  rec_wait();
  rec_wait();
  m=&msg[22];
  for(i=0;i<10;i++)
  {
   mob[i]=*m;
   *m++;
  }
  rec_wait();
  REN=0;
  delay(1);
  send_mess("AT+CMGDA=\"DEL ALL\"\r\n");
  delay(2);
  lcd_pos(1,1);
  lcd_print("                ");
  lcd_pos(1,1);
  lcd_print(mob);
  lcd_pos(2,1);
  lcd_print("                ");
  lcd_pos(2,1);
  lcd_print(msg);
 }
}

void serial_int() __interrupt(4)
{
 if(RI==1)
 {
  get_msg();
 }

 else
 {
  TI=0;
  sent=1;
 }
}

void send_mess(char *t)
{
 sent=0;
 while(*t!=0x00)
 {
  SBUF=*t;
  *t++;
  trans_wait();
 }
}

void start_serial(long int baud)
{
 int count;
 TR1=0;
 SCON=0x50;
 TMOD=(TMOD&0x0F)|0x20;
 count=256-(GSM_CLK/baud);
 TH1=count;
 TL1=count;
 TR1=1;
 ES=1;
 EA=1;
}

void trans_wait()
{
 while(sent==0)
 {}
 sent=0;
}

void rec_wait()
{
 m=&msg[0];
 while(rec==0)
 {}
 rec=0;
}

void get_msg()
{
  RI=0;
  if(SBUF==0x0A)
  {
   rec=1;
   m=&msg[0];
  }
  else if(SBUF==0x0D)
  {
   *m=0x00;
   *m++;
  }
  else
  {
   *m=SBUF;
   *m++;
  }
}

__bit check_msg(char *dig)
{
 m=&msg[0];
 while(*dig!=0x00)
 {
  if(*dig==*m)
  {
   chk=1;
  }
  else
  {
   chk=0;
   break;
  }
  *dig++;
  *m++;
 }
 return chk;
}