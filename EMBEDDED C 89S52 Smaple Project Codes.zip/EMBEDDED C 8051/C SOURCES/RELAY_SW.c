#include <AT89S52.h>
#define SW P3_3
#define LAMP P0_0

void main()
{
 while(1)
 {
  if(SW==1)
  {
   LAMP=1;
  }
  else
  {
   LAMP=0;
  }
 }
}