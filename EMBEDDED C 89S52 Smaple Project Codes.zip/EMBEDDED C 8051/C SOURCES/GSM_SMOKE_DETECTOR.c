#include <AT89S52.h>

#define GSM_FOSC 11059200
#define GSM_CLK GSM_FOSC/384

#define SEN P2_0

void start_serial(long int);
void send_mess(char*);
void trans_wait(void);

__bit sent;


void main()
{
 sent=0;
 start_serial(9600);
 delay(1);
 send_mess("ATE0\r\n");
 delay(1);
 send_mess("AT+CMGF=1\r\n");
 delay(1);
 send_mess("AT+CMGDA=\"DEL ALL\"\r\n");
 delay(2);
 while(1)
 {
  while(SEN==1)
  {
  }
  send_mess("AT+CMGS=\"6379389503\"\r\n");
  delay(1);
  send_mess("SMOKE DETECTED");
  delay(1);
  SBUF=0x1A;
  trans_wait();
  delay(5);
  send_mess("AT+CMGDA=\"DEL ALL\"\r\n");
  delay(15);
  send_mess("ATD6379389503;\r\n");
  delay(40);
  send_mess("ATH\r\n");
  while(SEN==0)
  {
  }
 }
}

void serial_int() __interrupt(4)
{
 if(RI==1)
 {
  RI=0;
 }

 else
 {
  TI=0;
  sent=1;
 }
}

void send_mess(char *t)
{
 sent=0;
 while(*t!=0x00)
 {
  SBUF=*t;
  *t++;
  trans_wait();
 }
}

void start_serial(long int baud)
{
 int count;
 TR1=0;
 SCON=0x40;
 TMOD=(TMOD&0x0F)|0x20;
 count=256-(GSM_CLK/baud);
 TH1=count;
 TL1=count;
 TR1=1;
 ES=1;
 EA=1;
}

void trans_wait()
{
 while(sent==0)
 {}
 sent=0;
}