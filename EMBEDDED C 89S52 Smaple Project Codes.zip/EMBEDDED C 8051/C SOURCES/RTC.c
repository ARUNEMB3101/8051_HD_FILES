#include <AT89S52.h>

#define SCL P0_1
#define SDA P0_0
#include <RTC.h>

#define RS P0_2
#define RW P0_3
#define EN P0_4
#define DATABUS P2
#include <LCD.h>

void disp_time(void);
void disp_date(void);
void print_rtc(void);

const char ascii[11]="0123456789";

void main()
{
 lcd_init();
 while(1)
 {
  print_rtc();
 }
}

void disp_time()
{
 char n1;
 lcd_pos(1,1);
 lcd_print("Time: ");
 for(n1=3;n1>0;n1--)
 {
  if(n1!=1)
  {
   lcd_data(ascii[(rtc_reg[n1-1]>>4)]);
   lcd_data(ascii[(rtc_reg[n1-1]&0x0F)]);
   lcd_data(':');
  }
  else
  {
   lcd_data(ascii[(rtc_reg[n1-1]>>4)]);
   lcd_data(ascii[(rtc_reg[n1-1]&0x0F)]);
  }
 }
}

void disp_date()
{
 char n2;
 lcd_pos(2,1);
 lcd_print("Date: ");
 for(n2=4;n2<7;n2++)
 {
  if(n2!=6)
  {
   lcd_data(ascii[(rtc_reg[n2]>>4)]);
   lcd_data(ascii[(rtc_reg[n2]&0x0F)]);
   lcd_data('/');
  }
  else
  {
   lcd_data(ascii[(rtc_reg[n2]>>4)]);
   lcd_data(ascii[(rtc_reg[n2]&0x0F)]);
  }
 }
}

void print_rtc()
{
 read_rtc();
 disp_time();
 disp_date();
}