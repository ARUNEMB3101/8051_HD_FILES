#include <AT89S52.h>
#define RW P0_2
#define RS P0_1
#define EN P0_0
#define DATABUS P2
#include <LCD.h>
#define TRIG P0_7
#define ECHO P0_6
#include <ULTRASONIC.h>

char dis[11]="0123456789";

void main()
{
 int m;
 char a,b,c;
 lcd_init();
 lcd_print("Distance=");
 while(1)
 {
  m=get_distance();
  a=m/100;
  c=m%10;
  b=(m-(a*100)-c)/10;
  lcd_pos(1,10);
  lcd_data(dis[a]);
  lcd_data(dis[b]);
  lcd_data(dis[c]);
  lcd_print(" Cm");
  delay(1);
 }
}