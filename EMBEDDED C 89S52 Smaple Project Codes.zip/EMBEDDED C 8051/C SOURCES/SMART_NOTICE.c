#include <AT89S52.h>

#define BLUE_FOSC 11059200
#define BLUE_CLK BLUE_FOSC/384
#define RS P1_0
#define RW P1_1
#define EN P1_2
#define DATABUS P0
#include <LCD.h>
#define STATE P2_0

void timer_init(void);
void start_serial(long int);
void send_mess(char*);
void trans_wait(void);
void rec_wait(void);
void get_msg(void);
__bit check_msg(char*);

__bit sent,rec,chk;
char msg[70];
char *m;
char mob[5];
char scan;
void main()
{
 scan=0;
 lcd_init();
 start_serial(9600);
 timer_init();
 lcd_pos(1,1);
 lcd_print("  Wireless Home ");
 lcd_pos(2,1);
 lcd_print("   Automation   ");
 delay(5);
 while(STATE==0)
 {}
 send_mess("Enter a message to display:\r\n");
 while(1)
 {
  rec_wait();
  lcd_cmd(0x01);
  lcd_pos(1,5);
  lcd_print(msg);
  send_mess(msg);
  send_mess("\r\n");
  send_mess("Message displayed sucessfully!!!\r\n\r\n");
  send_mess("Enter a new message to be display:\r\n");
 }
}


void send_mess(char *t)
{
 sent=0;
 while(*t!=0x00)
 {
  SBUF=*t;
  *t++;
  trans_wait();
 }
}

void start_serial(long int baud)
{
 int count;
 TR1=0;
 SCON=0x50;
 TMOD=(TMOD&0x0F)|0x20;
 count=256-(BLUE_CLK/baud);
 TH1=count;
 TL1=count;
 TR1=1;
 ES=1;
 PS=1;
 EA=1;
}

void trans_wait()
{
 while(sent==0)
 {}
 sent=0;
}

void rec_wait()
{
 m=&msg[0];
 while(rec==0)
 {}
 rec=0;
}

void get_msg()
{
  RI=0;
  if(SBUF==0x0A)
  {
   rec=1;
   m=&msg[0];
  }
  else if(SBUF==0x0D)
  {
   *m=0x00;
   *m++;
  }
  else
  {
   *m=SBUF;
   *m++;
  }
}

__bit check_msg(char *dig)
{
 m=&msg[0];
 while(*dig!=0x00)
 {
  if(*dig==*m)
  {
   chk=1;
  }
  else
  {
   chk=0;
   break;
  }
  *dig++;
  *m++;
 }
 return chk;
}

void timer_init()
{
 TR0=0;
 TMOD=(TMOD&0xF0)|0x01;
 TH0=0x00;
 TH0=0x00;
 ET0=1;
 EA=1;
 TR0=1;
}

void timer_int() __interrupt(1)
{
 scan++;
 if(scan==10)
 { 
  scan=0;
  lcd_cmd(0x18);
 }
 else
 {
 }
}

void serial_int() __interrupt(4)
{
 if(RI==1)
 {
  get_msg();
 }
 else
 {
  TI=0;
  sent=1;
 }
}