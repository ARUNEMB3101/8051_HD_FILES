#include <AT89S52.h>
#include <TIMERU.h>

#define LED P2_0

void main()
{
 LED=1;
 while(1)
 {
  LED=0;
  timer0_5ms(500);
  LED=1;
  timer0_5ms(500);
 }
}