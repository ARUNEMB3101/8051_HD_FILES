#include <AT89S52.h>
#include <RFID.h>

#define PULSE P1_0
#include <SERVO.h>

#define RS P1_0
#define RW P1_1
#define EN P1_2
#define DATABUS P0
#include <LCD.h>

void main()
{
 __bit chk=0;
 char q;
 lcd_init();
 lcd_line(1);
 lcd_print("ID:");
 start_serial(9600);
 rfid_start();
 servo_init();
 run_servo(R);
 delay(5);
 while(1)
 {
  rfid_start();
  rfid_wait();
  chk=rfid_verify("2700227BD7A9");
  if(chk==1)
  {
   lcd_pos(1,4);
   lcd_print(rfid_buff);
   lcd_line(2);
   lcd_print("Valid tag  ");
   for(q=1;q<13;q++)
   {
    run_servo(q);
    q++;
   }
   delay(10);
   run_servo(R);
  }
  else
  {
   lcd_pos(1,4);
   lcd_print(rfid_buff);
   lcd_line(2);
   lcd_print("Invalid tag");
  }
 }
}

void serial_int() __interrupt(4)
{
 if(RI==1)
 {
  get_rfid();
 }
 
 else
 {
  TI=0;
 }
}