#include <AT89S52.h>

#define RS P1_0
#define RW P1_1
#define EN P1_2
#define DATABUS P0
#include <LCD.h>

#include <TIMERU.h>
#define LED P2_0

void disp_time(char);

void main()
{
 char sec=0;
 lcd_init();
 lcd_pos(1,2);
 lcd_print("DIGITAL CLOCK");
 LED=1;
 while(1) 
 {
  while(sec<60)
  {
   disp_time(sec);
   timer_sec(1);
   LED=!LED;
   sec++;
  }
  sec=0;
  disp_time(sec);
  LED=!LED;
 }
}

void disp_time(char ss)
{
 char s1,s0;
 s1=(ss/10)|0x30;
 lcd_pos(2,8);
 lcd_data(s1);
 s0=(ss%10)|0x30;
 lcd_data(s0);
}