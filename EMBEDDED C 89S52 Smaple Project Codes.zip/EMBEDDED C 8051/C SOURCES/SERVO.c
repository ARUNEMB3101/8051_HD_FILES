#include <AT89S52.h>
#define FOSC 11059200
#define CLK FOSC/12
#define PWM CLK/50


long int TON,TOFF;
__sbit c,b;
char hb1,lb1,hb0,lb0;
char n;

void run_servo(char);
void delay(void);


void main()
{
 c=0;
 n=0;
 TMOD=(TMOD&0XF0)|0x01;
 IE=0X82;
 while(1)
 {
  run_servo(0);
  delay();
  run_servo(90);
  delay();
 }
}

void run_servo(char ang)
{
  b=0;
  TON=((PWM/2)+(PWM/2)*(ang/90))/10;
  TOFF=PWM-TON;
  TON=(0xFFFF-TON)+1;
  TOFF=(0xFFFF-TOFF)+1;
  hb1=(TON/256);
  lb1=(TON%256);
  hb0=(TOFF/256);
  lb0=(TOFF%256);
  TF0=1;
  while(b==0)
  {}
  b=0;
}

void timer0_int() __interrupt(1)
{
 if(n==200)
 {
  TR0=0;
  n=0;
  c=0;
  b=1;
 }
 else if(c==0)
 {
  c=1;
  TR0=0;
  TH0=hb1;
  TL0=lb1;
  TR0=1;
  P0_0=1;
  n++;
 }
 else if(c==1)
 {
  c=0;
  TR0=0;
  TH0=hb0;
  TL0=lb0;
  TR0=1;
  P0_0=0;
  n++;
 }
 else
 {}
}

void delay()
{
 long int i;
 for(i=0;i<30000;i++)
 {}
}