#include <AT89S52.h>

#define RS P0_2
#define RW P0_1
#define EN P0_0
#define DATABUS P1
#include <LCD_4BIT.h>

void main()
{
 lcd_start();
 lcd_init();
 lcd_print("Good Evening!");
 lcd_cmd(0xC0);
 lcd_print("Have a Nice Day!");
 while(1)
 {
  lcd_cmd(0x0C);
  delay(1);
  lcd_cmd(0x08);
  delay(1);
 }
}