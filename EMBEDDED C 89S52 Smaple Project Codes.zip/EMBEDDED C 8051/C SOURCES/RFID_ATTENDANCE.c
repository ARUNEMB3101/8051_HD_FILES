#include <AT89S52.h>

#define RS P1_0
#define RW P1_1
#define EN P1_2
#define DATABUS P2
#include <LCD.h>

#include <RFID.h>

void main()
{
 lcd_init();
 lcd_print("ID:");
 start_serial(9600);
 while(1)
 {
  rfid_start();
  rfid_wait();
  lcd_pos(1,4);
  lcd_print(rfid_buff);
  if(rfid_verify("1000697E8285")==1)
  {
   lcd_pos(2,1);
   lcd_print("Athira PR  ");
  }
  else
  {
   lcd_pos(2,1);
   lcd_print("Invalid tag");
  }
 }
}

void rfid() __interrupt(4)
{
 if(RI==1)
 {
  get_rfid();
 }
 else if(TI==1)
 {
  TI=0;
 }
}