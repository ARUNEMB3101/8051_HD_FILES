#include <AT89S52.h>
#include <TIMERU.h>

#define S P3_5
#define RS P0_0
#define RW P0_1
#define EN P0_2
#define DATABUS P1
#include <LCD.h>

int rpm,d2,d1,d0;
char asci[11]="0123456789";
void timer1_init(void);
void main()
{
 S=1;
 rpm=0;
 lcd_init();
 timer1_init();
 lcd_print("Motor Speed:");
 while(S==1)
 {}
 while(1)
 {
  TR1=1;
  timer_sec(1);
  TR1=0;
  rpm=6*((TH1*256)+TL1);
  TH1=0x00;
  TL1=0x00;
  d2=(rpm/100);
  d1=(rpm/10)%10;
  d0=(rpm%10);
  lcd_line(2);
  lcd_data(asci[d2]);
  lcd_data(asci[d1]);
  lcd_data(asci[d0]);
  lcd_data('0');
  lcd_print(" RPM");
 }
}

void timer1_init()
{
 TR1=0;
 TMOD=(TMOD&0x0F)|0x50;
 TH1=0x00;
 TL1=0x00;
}