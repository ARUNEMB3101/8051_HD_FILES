#include <AT89S52.h>


#define RS P0_2
#define RW P0_1
#define EN P0_0
#define DATABUS P2
#include <LCD.h>

#define TRIG P0_3
#define ECHO P0_4
#include <ULTRASONIC.h>

#define PUMP P0_5

char asci[11]="0123456789";
char level[4];

void main()
{
 char h,t,o;
 int d,lev;
 char n;
 PUMP=1;
 lcd_init();
 lcd_print("WATER LEVEL CON");
 lcd_line(2);
 lcd_print("Level:   %");
 while(1)
 {
  lev=get_distance();
  if(lev<=50)
  {
   d=100-(lev*2);
   h=d/100;
   t=(d/10)%10;
   o=d%10;
   level[0]=asci[h];
   level[1]=asci[t];
   level[2]=asci[o];
   lcd_pos(2,7);
   for(n=0;n<3;n++)
   {
    lcd_data(level[n]);
   }
   delay(1);

   if(lev>=45)
   {
    PUMP=0;
   }
   else if(lev<=5)
   {
    PUMP=1;
   }
   else
   {
   }
  }
  else
  {
  }
 }
}
