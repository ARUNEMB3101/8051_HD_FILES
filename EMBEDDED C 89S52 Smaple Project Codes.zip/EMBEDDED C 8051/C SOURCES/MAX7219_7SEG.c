#include <AT89S52.h>

#define CS  P2_1
#define CLK P2_2
#define DIN P2_0
#include <MAX7219_7SEG.h>

#define SCL P3_0
#define SDA P3_1
#include <RTC.h>

char time[9];

void main()
{
 delay(10);
 DIN=0;CLK=0;CS=0;
 write_byte(0x0C);
 write_byte(0x01);
 write_byte(0x0C);
 write_byte(0x01);
 load();

 write_byte(0x0F);
 write_byte(0x00);
 write_byte(0x0F);
 write_byte(0x00);
 load();
 
 write_byte(0x0B);
 write_byte(0x07);
 write_byte(0x0B);
 write_byte(0x07);
 load();
 
 write_byte(0x09);
 write_byte(0xFF);
 write_byte(0x09);
 write_byte(0xFF);
 load();
 
 write_byte(0x0A);
 write_byte(0x0F);
 write_byte(0x0A);
 write_byte(0x0F);
 load();

 while(1)
 {
  write_byte(0x05);
  write_byte(rtc_get(RTC_SEC)&0x0F);
  write_byte(0x01);
  write_byte(rtc_get(RTC_YR)&0x0F);
  load();
  write_byte(0x06);
  write_byte((rtc_get(RTC_SEC)&0xF0)>>4);
  write_byte(0x02);
  write_byte((rtc_get(RTC_YR)&0xF0)>>4);
  load();
  write_byte(0x07);
  write_byte(0x0A);
  write_byte(0x03);
  write_byte(0x0A);
  load();

  write_byte(0x08);
  write_byte(rtc_get(RTC_MIN)&0x0F);
  write_byte(0x04);
  write_byte(rtc_get(RTC_MON)&0x0F);
  load();
  write_byte(0x01);
  write_byte((rtc_get(RTC_MIN)&0xF0)>>4);
  write_byte(0x05);
  write_byte((rtc_get(RTC_MON)&0xF0)>>4);
  load();
  write_byte(0x02);
  write_byte(0x0A);
  write_byte(0x06);
  write_byte(0x0A);
  load();

  write_byte(0x03);
  write_byte(rtc_get(RTC_HR)&0x0F);
  write_byte(0x07);
  write_byte(rtc_get(RTC_DAT)&0x0F);
  load();
  write_byte(0x04);
  write_byte((rtc_get(RTC_HR)&0xF0)>>4);
  write_byte(0x08);
  write_byte((rtc_get(RTC_DAT)&0xF0)>>4);
  load();
 }
}