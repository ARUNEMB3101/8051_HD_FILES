#include <AT89S52.h>
#define PULSE P0_0
#include <SERVO.h>
#define DATABUS P2
#define RS P0_7
#define RW P0_6
#define EN P0_5
#include <LCD.h>
#define TRIG P0_1
#define ECHO P0_2
#include <ULTRASONIC.h>


void main()
{
 char i,dist;
 lcd_init();
 lcd_print("MY RADAR");
 servo_init();
 while(1)
 {
  for(i=1;i<10;i++)
  {
   run_servo(i);
   dist=get_distance();
   if(dist<50)
   {
    lcd_pos(2,1);
    lcd_print("Be Alert");
   }
   else
   {
    lcd_pos(2,1);
    lcd_print("No Alert");
   }
  }

  for(i=9;i>0;i--)
  {
   run_servo(i);
   dist=get_distance();
   if(dist<50)
   {
    lcd_pos(2,1);
    lcd_print("Be Alert");
   }
   else
   {
    lcd_pos(2,1);
    lcd_print("No Alert");
   }
  }
 }
}