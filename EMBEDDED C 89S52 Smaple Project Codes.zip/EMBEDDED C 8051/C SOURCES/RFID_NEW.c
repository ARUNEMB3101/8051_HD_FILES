#include <AT89S52.h>
#include <RFID.h>

#define RS P0_0
#define RW P0_1
#define EN P0_2
#define DATABUS P2
#include <LCD.h>


void main()
{
 lcd_init();
 lcd_line(1);
 lcd_print("ID:");
 start_serial(9600);
 rfid_start();
 delay(5);
 while(1)
 {
  rfid_start();
  rfid_wait();
  lcd_pos(1,4);
  lcd_print(rfid_buff);
  delay(10);
 }
}

void serial_int() __interrupt(4)
{
 if(RI==1)
 {
  get_rfid();
 }
 
 else
 {
  TI=0;
 }
}