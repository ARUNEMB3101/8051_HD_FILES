#include <AT89S52.h>
#define FOSC 11059200
#define SCLK FOSC/384

#define L1 P2_0
#define L2 P2_1
#define L3 P2_2
#define L4 P2_3

void start_serial(long int);
void send_mess(char*);
char CON;
__sbit c,d,a1,a2,a3,a4;
char *b;

void main()
{
 c=0;
 d=0;
 a1=0;
 a2=0;
 a3=0;
 a4=0;
 L1=1;
 L2=1;
 L3=1;
 L4=1;
 delay(5);
 start_serial(9600);
 while(1)
 {
  while(c==0)
  {}
  c=0;
  if(CON==1)
  {
   L1=!L1;
   a1=!a1;
  }
  else if(CON==2)
  {
   L2=!L2;
   a2=!a2;
  }
  else if(CON==3)
  {
   L3=!L3;
   a3=!a3;
  }
  else if(CON==4)
  {
   L4=!L4;
   a4=!a4;
  }
  else
  {
  }

  send_mess("LAMP CONDITIONS: \r\n");
  if(a1==1)
  {
   send_mess("LAMP1 is ON \t");
  }
  else
  {
   send_mess("LAMP1 is OFF \t");
  }
  if(a2==1)
  {
   send_mess("LAMP2 is ON \t");
  }
  else
  {
   send_mess("LAMP2 is OFF \t");
  }
  if(a3==1)
  {
   send_mess("LAMP3 is ON \t");
  }
  else
  {
   send_mess("LAMP3 is OFF \t");
  }
  if(a4==1)
  {
   send_mess("LAMP4 is ON\r\n\r\n\r\n");
  }
  else
  {
   send_mess("LAMP4 is OFF\r\n\r\n\r\n");
  }
 }
}

void start_serial(long int baud)
{
 long int count;
 TR1=0;
 SCON=SCON|0x50;
 TMOD=(TMOD&0x0F)|0x20;
 count=256-(SCLK/baud);
 TH1=count;
 TL1=count;
 TR1=1;
 ES=1;
 EA=1;
}

void send_mess(char *mess)
{
 d=0;
 while(*mess!=0x00)
 {
  SBUF=*mess;
  *mess++;
  while(d==0)
  {
  }
  d=0;  
 }
}

void serial_interrupt() __interrupt(4)
{
 if(RI==1)
 {
  RI=0;
  CON=SBUF;
  c=1;
 }

 else
 {
  TI=0;
  d=1;
 }
}