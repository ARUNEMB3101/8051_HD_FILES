#include <AT89S52.h>
#define SIM_FOSC 11059200
#define SIM_CLK SIM_FOSC/384
#define RS P1_0
#define RW P1_1
#define EN P1_2
#define DATABUS P0
#include <LCD.h>

void send_mess(char*);
void start_serial(long int);
void trans_wait(void);
void rec_wait(void);
__bit sent,rec;
char msg[80];
char *m;

void main()
{
 m=&msg[0];
 lcd_init();
 start_serial(9600);
 lcd_print("Vehicle Tracking");
 while(1)
 {
  send_mess("AT+CMGF=1\r\n");
  delay(1);
  send_mess("AT+CMGS=\"9940900503\"\r\n");
  delay(1);
  send_mess("Naalaike parthukalam sir...\r\n");
  delay(1);
  send_mess("Room ke poagalaam ji...\r\n");
  delay(1);
  send_mess("By Ram...\r\n");
  delay(1);
  SBUF=0x1A;
  trans_wait();
  delay(30);
  send_mess("ATD9940900503;\r\n");
  while(1)
  {}
 }
}

void serial_int() __interrupt(4)
{
 if(RI==1)
 {
  RI=0;
  if(SBUF!=0x0D)
  {
   *m=SBUF;
   *m++;
  }
  else if(SBUF==0x0D)
  {
   *m=0x00;
   *m++;
  }  
  else if(SBUF==0x0A)
  {
   rec=1;
   m=&msg[0];
  }
  else
  {
  }
 }

 else if(TI==1)
 {
  TI=0;
  sent=1;
 }
 else
 {
 }
 
}

void send_mess(char *p)
{
 sent=0;
 while(*p!=0x00)
 {
  SBUF=*p;
  *p++;
  trans_wait();
 }
}

void start_serial(long int baud)
{
 int count;
 TR1=0;
 SCON=0x50;
 TMOD=(TMOD&0x0F)|0x20;
 count=256-(SIM_CLK/baud);
 TH1=count;
 TL1=count;
 TR1=1;
 ES=1;
 EA=1;
}

void trans_wait()
{
 sent=0;
 while(sent==0)
 {}
 sent=0;
}

void rec_wait()
{
 rec=0;
 while(rec==0)
 {}
 rec=0;
}