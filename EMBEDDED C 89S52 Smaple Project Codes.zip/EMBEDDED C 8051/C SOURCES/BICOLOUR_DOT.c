#include <AT89S52.h>

void delay(int);
void main()
{
 while(1)
 {
  P2=0x00;
  P0=0xFF;
  delay(1);
  P0=0X00;
  P2=0XFF;
  

  P3=0x00;
  P0=0xFF;
  delay(1);
  P0=0X00;
  P3=0XFF;
  
  
 }
}

void delay(int d)
{
 int i,j;
 for(i=0;i<d;i++)
 {
  for(j=0;j<30000;j++)
  {
  }
 }
}