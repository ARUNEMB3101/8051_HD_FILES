#include <AT89S52.h>

#define CS  P2_1
#define CLK P2_2
#define DIN P2_0
#include <MAX7219_DOTMAT.h>

#define SCL P3_0
#define SDA P3_1
#include <RTC.h>

void main()
{
 init();
 load();
 delay(10);
 while(1)
 {
  clear();
  delay(10);
  print(((rtc_get(RTC_HR)&0xF0)>>4)|0x30);
  delay(10);
  print((rtc_get(RTC_HR)&0x0F)|0x30);
  delay(10);
  clear();
  write(2,0x18);
  write(3,0x18);
  write(5,0x18);
  write(6,0x18);
  delay(10);
  print(((rtc_get(RTC_MIN)&0xF0)>>4)|0x30);
  delay(10);
  print((rtc_get(RTC_MIN)&0x0F)|0x30);
  delay(10);
 }
}