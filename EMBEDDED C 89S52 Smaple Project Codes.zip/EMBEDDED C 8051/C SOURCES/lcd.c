#include <AT89S52.h>
#define RS P0_0
#define RW P0_1
#define EN P0_2
#define DATABUS P2
#define KEYPAD P3
#include <LCD.h>
#include <KEYPAD.h>
char key_in[17]="123A456B789C*0#D";
void main()
{
 char k;
 lcd_init();

 while(1)
 {
  lcd_pos(1,1);
 lcd_print("Vishwa");
 delay(1);
 lcd_cmd(0x01);
 delay(1);

 lcd_pos(1,12);
 lcd_print("Ashok");
 delay(1);
 lcd_cmd(0x01);
 delay(1);
 
 lcd_pos(2,6);
 lcd_print("Madhan");
 delay(1);
 lcd_cmd(0x01);
 delay(1);
 }
}