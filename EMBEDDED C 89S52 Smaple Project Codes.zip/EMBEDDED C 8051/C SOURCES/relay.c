#include <AT89S52.h>
#define LAMP P3_3

void delay(void);
void main()
{
 while(1)
 {
  LAMP=0;
  delay();
  LAMP=1;
  delay();
 }
}

void delay()
{
 long int i;
 for(i=0;i<600000;i++)
 {
 }
}