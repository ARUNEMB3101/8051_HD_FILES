#include <AT89S52.h>

#define SCL P2_7
#define SDA P2_6
#define SID 0x7C
#include <I2C_LCD.h>

void main()
{
 __bit flag;
 delay(10);
 i2c_lcd_start();
 i2c_lcd_init();
 i2c_lcd_print("Thank you all of you!!!");
 while(1)
 {
  while(P3_3==0)
  {
    flag=!flag;
    while(P3_3==0)
    {}
  }
  if(flag==0)
  {
   i2c_lcd_off();
  }
  else if(flag==1)
  {
   i2c_lcd_on();
  }
  else
  {}
 }
}