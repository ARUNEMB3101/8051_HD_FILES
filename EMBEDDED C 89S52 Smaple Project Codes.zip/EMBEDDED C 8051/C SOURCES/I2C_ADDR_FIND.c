#include <AT89S52.h>

#define SCL P0_1
#define SDA P0_0
#include <I2C.h>

#define RS P0_2
#define RW P0_3
#define EN P0_4
#define DATABUS P2
#include <LCD.h>

char i2c_addr(void);

char ascii[17]="0123456789ABCDEF";

void main()
{
 char addr;
 lcd_init();
 while(1)
 {
  lcd_line(1);
  lcd_print("I2C ADDR: 0x");
  addr=i2c_addr();
  lcd_data(ascii[(addr>>4)]);
  lcd_data(ascii[(addr&0x0F)]);
 }
}

char i2c_addr()
{
 char b,c;
 __bit ver;
 ver=1;b=0x00;
 i2c_init();
 while(ver==1)
 {
  i2c_start();
  for(c=0;c<8;c++)
  {
   if(((b<<c)&(0x80))!=0x00)
   {
    SDA=1;
   }
   else
   {
    SDA=0;
   }
   i2c_clk();
  }
  SDA=1;
  SCL=1;
  ver=SDA;
  SCL=0;
  SDA=0;
  i2c_stop();
  b++;
 }
 b--;
 return b;
}