#include <AT89S52.h>

#define RS P1_0
#define RW P1_1
#define EN P1_2
#define DATABUS P0
#include <LCD.h>

#define KEYPAD P2
#include <KEYPAD.h>

#include <RFID.h>


char asci[17]="123A456B789C*0#D";
char num[11]="0123456789";
char t1;
void main()
{
 t1=9;
 lcd_init();
 lcd_print("Fast Tag Toll");
 delay(1);
 start_serial(9600);
 EX0=1;
 IT0=1;
 PS=1;
 EA=1;
 lcd_init();
 lcd_print("swipe the tag   ");
 rfid_start();
 rfid_wait();
 lcd_init();
 delay(1);
 while(1)
 {
  lcd_pos(2,1);
  lcd_print("wait");
  delay(1);
  lcd_pos(2,1);
  lcd_print(rfid_buff);
  delay(1);
  if(rfid_verify("2600A46B7A93")==1)
  {
   t1--;
   if(t1==0)
   {
    IE0=1;
   }
   else
   {
   }
   lcd_cmd(0x01);
   lcd_line(1);
   lcd_print("Balance: ");
   lcd_data(num[t1]);
   lcd_print("00");
   delay(1);
  }
  else if(rfid_verify("2600A46B7A93")==0)
  {
   lcd_cmd(0X01);
   lcd_line(1);
   lcd_print("Invalid tag");
   delay(1);
  }
  else
  {
  }
  lcd_init();
  lcd_print("swipe the tag   ");
  delay(1);
  rfid_start();
  rfid_wait();
 }
}

void ser_int() __interrupt(4)
{
 if(RI==1)
 {
  get_rfid();
 }
 else if(TI==1)
 {
  TI=0;
 }
 else
 {
 }
}

void toll_reg() __interrupt(0)
{
 char key;
 lcd_pos(1,1);
 lcd_print("Swipe the tag   ");
 delay(5);
 rfid_start();
 rfid_wait();
 lcd_pos(2,1);
 lcd_print(rfid_buff);
 delay(5);
 if(rfid_verify("2600A46B7A93")==1)
 {
  lcd_pos(1,1);
  lcd_print("Enter amt:   ");
  key=read_key();
  lcd_data(asci[key]);
  t1=(asci[key]-0x30);
  lcd_print("00");
  delay(5);
  lcd_pos(1,1);
  lcd_print("swipe the tag   ");
  delay(5);
 }
 else if(rfid_verify("2600A46B7A93")==0)
 {
  lcd_cmd(0X01);
  lcd_line(1);
  lcd_print("Invalid tag     ");
  delay(5);
 }
 else
 {
 }
 rfid_start();
 IE0=0;
 TI=0;
 RI=0;
}