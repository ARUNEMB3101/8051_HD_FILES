#include <AT89S52.h>

#define KEYPAD P2
#include <KEYPAD.h>

#define RS P1_0
#define RW P1_1
#define EN P1_4
#define DATABUS P0
#include <LCD.h>

char asci[17]="123A456B789C*0#D";

void main()
{

}