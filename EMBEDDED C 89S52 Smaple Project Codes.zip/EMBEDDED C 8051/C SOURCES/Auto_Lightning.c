#include <AT89S52.h>
#define PIR  P3_3
#define RELAY P0_0

void main()
{
 while(1)
 {
  if(PIR==1)
  {
   RELAY=1;
  }
  else
  {
   RELAY=0;
  }
 }
}