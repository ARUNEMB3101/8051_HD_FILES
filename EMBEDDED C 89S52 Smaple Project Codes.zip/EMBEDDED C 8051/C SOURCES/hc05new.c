#include <AT89S52.h>
#define FOSC 11059200
#define SCLK FOSC/384

#define MRIN1 P1_0
#define MRIN2 P1_1
#define MLIN1 P1_2
#define MLIN2 P1_3


void start_serial(long int);
void send_mess(char*);
char CON;
__sbit c,d;

void main()
{
 c=0;
 d=0;
 MRIN1=0;
 MRIN2=0;
 MLIN1=0;
 MLIN2=0;
 delay(5);
 start_serial(9600);
 send_mess("WIRELESS ROBOT CAR\r\n");
 while(1)
 {
  while(c==0)
  {}
  c=0;
  send_mess("Motor is");
  if(CON=='R')
  {
   send_mess("Moving Right\r\n\r\n");
  }
  else if(CON=='L')
  {
   send_mess("Moving Left\r\n\r\n");
  }
  else if(CON=='F')
  {
   send_mess("Moving Front\r\n\r\n");
  }
  else if(CON=='B')
  {
   send_mess("Moving Back\r\n\r\n");
  }
  else
  {
   send_mess("Stopped now\r\n\r\n");
  }
 }
}

void start_serial(long int baud)
{
 long int count;
 TR1=0;
 SCON=SCON|0x50;
 TMOD=(TMOD&0x0F)|0x20;
 count=256-(SCLK/baud);
 TH1=count;
 TL1=count;
 TR1=1;
 ES=1;
 EA=1;
}

void send_mess(char *mess)
{
 d=0;
 while(*mess!=0x00)
 {
  SBUF=*mess;
  *mess++;
  while(d==0)
  {
  }
  d=0;  
 }
}

void serial_interrupt() __interrupt(4)
{
 if(RI==1)
 {
  RI=0;
  CON=SBUF;
  c=1;
 }

 else
 {
  TI=0;
  d=1;
 }
}