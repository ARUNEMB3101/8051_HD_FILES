#include <AT89S52.h>

#define RS P1_0
#define RW P1_1
#define EN P1_2
#define DATABUS P0
#include <LCD.h>

#define ADC P3
#define A2 P2_2
#define A1 P2_1
#define A0 P2_0
#define AL P2_3
#define SOC P2_4
#define EOC P2_5
#define OE P2_6

#define FAN P2_7 
char asci[11]="0123456789";
char read_adc();
void main()
{
 char t,d2,d1,d0;
 FAN=1;
 lcd_init();
 A2=0;A1=0;A0=0;AL=0;SOC=0;EOC=1;OE=0;
 lcd_print("Digital Temp");
 while(1)
 {
  t=read_adc();
  d2=(t/100);
  d1=(t/10)%10;
  d0=t%10;
  lcd_pos(1,14);
  lcd_data(asci[d2]);
  lcd_data(asci[d1]);
  lcd_data(asci[d0]);
  delay(3);
  if(t>15)
  {
   FAN=0;
  }
  else if(t<=15)
  {
   FAN=1;
  }
  else
  {
  }
 }
}

char read_adc()
{
 char dval;
 AL=1;
 SOC=1;
 AL=0;
 SOC=0;
 while(EOC==1)
 {}
 while(EOC==0)
 {}
 OE=1;
 dval=ADC;
 OE=0;
 return dval;
}